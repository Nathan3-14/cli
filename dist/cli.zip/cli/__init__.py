from .cli import CLI, Command
from .funcs import error, create_dict_of_commands
